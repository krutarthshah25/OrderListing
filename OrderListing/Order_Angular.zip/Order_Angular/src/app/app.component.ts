import { HttpClient,  HttpClientModule } from '@angular/common/http';
import { Component, inject } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { filter, Observable } from 'rxjs';
import { Order } from '../models/order.models';
import { AsyncPipe } from '@angular/common';
import { OrderFilterComponent } from './order-filter/order-filter.component';

@Component({
  
  
  selector: 'app-root',
  standalone:true,
  imports: [RouterOutlet,AsyncPipe,HttpClientModule,OrderFilterComponent],
  
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})

export class AppComponent {
  http = inject(HttpClient);
 
 orders$ = this.getOrders();
  private getOrders():Observable<Order[]>
  {
    //debugger;
      return this.http.get<Order[]>('https://localhost:44350/api/Orders/GetOrders');
      // a.forEach(element => {
      //   alert(element[0].customerid)
      // });

  }
}
