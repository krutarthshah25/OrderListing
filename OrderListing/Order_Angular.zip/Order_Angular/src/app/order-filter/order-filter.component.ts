import { CommonModule } from '@angular/common';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { Component, inject, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-order-filter',
  standalone: true,
  imports: [CommonModule,HttpClientModule],
  templateUrl: './order-filter.component.html',
  //styleUrl: './order-filter.component.css',
  styleUrls: [
    './dataTables.dataTables.css',
    './order-filter.component.css'
  ], 
  encapsulation: ViewEncapsulation.None,
})


export class OrderFilterComponent implements OnInit {
 
  httpClient = inject(HttpClient);
  data:any[] = [];
ngOnInit(): void {
  this.fetchData();
}
  fetchData(){
    this.httpClient.get('https://localhost:44350/api/Orders/GetOrders')
    .subscribe((data:any)=>{
    console.log(data);
    this.data=data;
    });
  }

}
