export interface Order{
    orderid: string;
    customerid: string;
    orderdate: string;
    totalamount: string;

}